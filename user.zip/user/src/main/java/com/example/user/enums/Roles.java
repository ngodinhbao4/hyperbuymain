package com.example.user.enums;

public enum Roles {
    ADMIN,
    USER, 
    SELLER
}
